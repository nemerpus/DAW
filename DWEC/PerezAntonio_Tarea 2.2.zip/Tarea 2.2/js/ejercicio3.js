// Realizamos las diferentes comparaciones
let operacion1 = (10 == 10);
let operacion2 = (10 === 10);
let operacion3 = (10 === 10.0);
let operacion4 = ("Laura" == "laura");
let operacion5 = ("Laura" > "laura");
let operacion6 = ("Laura" < "laura");
let operacion7 = ("123" == 123);
let operacion8 = ("123" === 123);
let operacion9 = (parseInt("123") === 123);

// Mostramos el texto de cada operación y su resultado
alert("La operación 10 == 10 es " + operacion1);
alert("La operación 10 === 10 es " + operacion2);
alert("La operación 10 === 10.0 es " + operacion3);
alert('La operación "Laura" == "laura" es ' + operacion4);
alert('La operación "Laura" > "laura" es ' + operacion5);
alert('La operación "Laura" < "laura" es ' + operacion6);
alert('La operación "123" == 123 es ' + operacion7);
alert('La operación "123" === 123 es ' + operacion8);
alert('La operación parseInt("123") === 123 es ' + operacion9);